package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Enemy extends Sprite {
	
	private BufferedImage[] enemyImages ;
	public Enemy(BufferedImage[] enemyImages) throws Exception {
		this.enemyImages = enemyImages;
		x = GWIDTH ;
		
	}

	@Override
	public void printSprite(Graphics pen) {
		// TODO Auto-generated method stub
		
	}

}

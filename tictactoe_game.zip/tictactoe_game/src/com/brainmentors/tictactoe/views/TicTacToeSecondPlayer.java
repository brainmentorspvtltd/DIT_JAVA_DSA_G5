package com.brainmentors.tictactoe.views;






import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TicTacToeSecondPlayer {

	private JFrame frmTictactoegame;
	private boolean yourTurn = true;
	private boolean isXorZero = true;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					TicTacToeSecondPlayer window = new TicTacToeSecondPlayer();
					window.frmTictactoegame.setVisible(true);
				
	}

	/**
	 * Create the application.
	 */
	public TicTacToeSecondPlayer() {
		initialize();
	}
	
	private void sendX(int buttonPosition, JButton currentButton) {
		
	}
	
	private void placeZero() {
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	JButton one = new JButton("");
	JButton two = new JButton("");
	JButton three = new JButton("");
	JButton four = new JButton("");
	JButton five = new JButton("");
	JButton six = new JButton("");
	JButton seven = new JButton("");
	JButton eight = new JButton("");
	JButton nine = new JButton("");
	
	private void initialize() {
		frmTictactoegame = new JFrame();
		frmTictactoegame.setResizable(false);
		frmTictactoegame.getContentPane().setBackground(new Color(238, 232, 170));
		frmTictactoegame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TicTacToe - Second Player");
		lblNewLabel.setForeground(new Color(199, 21, 133));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 22));
		lblNewLabel.setBounds(282, 32, 350, 65);
		frmTictactoegame.getContentPane().add(lblNewLabel);
		one.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(1,one);
			}
		});
		
		
		one.setOpaque(true);
		one.setBackground(new Color(144, 238, 144));
		one.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		one.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		one.setBounds(74, 140, 184, 77);
		frmTictactoegame.getContentPane().add(one);
		two.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(2,two);
			}
		});
		
		
		two.setOpaque(true);
		two.setBackground(new Color(144, 238, 144));
		two.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		two.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		two.setBounds(307, 140, 184, 77);
		frmTictactoegame.getContentPane().add(two);
		three.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(3,three);
			}
		});
		
		
		three.setOpaque(true);
		three.setBackground(new Color(144, 238, 144));
		three.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		three.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		three.setBounds(534, 140, 184, 77);
		frmTictactoegame.getContentPane().add(three);
		four.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(4,four);
			}
			
		});
		
		
		four.setOpaque(true);
		four.setBackground(new Color(144, 238, 144));
		four.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		four.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		four.setBounds(74, 278, 184, 77);
		frmTictactoegame.getContentPane().add(four);
		five.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(5,five);
			}
		});
		
		
		five.setOpaque(true);
		five.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		five.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		five.setBackground(new Color(144, 238, 144));
		five.setBounds(307, 278, 184, 77);
		frmTictactoegame.getContentPane().add(five);
		six.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(6,six);
			}
		});
		
		
		six.setOpaque(true);
		six.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		six.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		six.setBackground(new Color(144, 238, 144));
		six.setBounds(534, 278, 184, 77);
		frmTictactoegame.getContentPane().add(six);
		seven.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(7,seven);
			}
		});
		
		
		seven.setOpaque(true);
		seven.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		seven.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		seven.setBackground(new Color(144, 238, 144));
		seven.setBounds(74, 400, 184, 77);
		frmTictactoegame.getContentPane().add(seven);
		eight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(8,eight);
			}
		});
		
		
		eight.setOpaque(true);
		eight.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		eight.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		eight.setBackground(new Color(144, 238, 144));
		eight.setBounds(307, 400, 184, 77);
		frmTictactoegame.getContentPane().add(eight);
		nine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendX(9,nine);
			}
		});
		
		
		nine.setOpaque(true);
		nine.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		nine.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		nine.setBackground(new Color(144, 238, 144));
		nine.setBounds(534, 400, 184, 77);
		frmTictactoegame.getContentPane().add(nine);
		frmTictactoegame.setTitle("TicTacToe-Game");
		frmTictactoegame.setBounds(100, 100, 815, 574);
		frmTictactoegame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTictactoegame.setLocationRelativeTo(null);
	}
}

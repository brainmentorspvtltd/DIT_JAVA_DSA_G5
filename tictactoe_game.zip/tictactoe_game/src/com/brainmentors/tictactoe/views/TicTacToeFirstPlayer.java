package com.brainmentors.tictactoe.views;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class TicTacToeFirstPlayer {

	private JFrame frmTictactoegame;
	private boolean yourTurn ;
	private boolean isXorZero = true;
	private ServerSocket server;
	private Socket socket;
	private final int PORT = 9001;
	private DataInputStream input;
	private DataOutputStream output;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					TicTacToeFirstPlayer window;
					try {
						window = new TicTacToeFirstPlayer();
						window.frmTictactoegame.setVisible(true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public TicTacToeFirstPlayer() throws IOException {
		initialize();
	}
	
	private void sendZero(int buttonPosition, JButton currentButton) {
		
	}
	
	private void placeX() {
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	JButton one = new JButton("");
	JButton two = new JButton("");
	JButton three = new JButton("");
	JButton four = new JButton("");
	JButton five = new JButton("");
	JButton six = new JButton("");
	JButton seven = new JButton("");
	JButton eight = new JButton("");
	JButton nine = new JButton("");
	
	
	private void netWorkInit() throws IOException {
		server  = new ServerSocket(PORT);
		// Waiting for Client...
		socket = server.accept();
		// Client Join
		input = new DataInputStream(socket.getInputStream());
		output = new DataOutputStream(socket.getOutputStream());
	}
	
	private void initialize() throws IOException {
		netWorkInit();
		frmTictactoegame = new JFrame();
		frmTictactoegame.setResizable(false);
		frmTictactoegame.getContentPane().setBackground(new Color(238, 232, 170));
		frmTictactoegame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TicTacToe - First Player");
		lblNewLabel.setForeground(new Color(199, 21, 133));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 22));
		lblNewLabel.setBounds(282, 32, 300, 65);
		frmTictactoegame.getContentPane().add(lblNewLabel);
		one.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(1,one);
			}
		});
		
		
		one.setOpaque(true);
		one.setBackground(new Color(144, 238, 144));
		one.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		one.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		one.setBounds(74, 140, 184, 77);
		frmTictactoegame.getContentPane().add(one);
		two.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(2,two);
			}
		});
		
		
		two.setOpaque(true);
		two.setBackground(new Color(144, 238, 144));
		two.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		two.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		two.setBounds(307, 140, 184, 77);
		frmTictactoegame.getContentPane().add(two);
		three.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(3,three);
			}
		});
		
		
		three.setOpaque(true);
		three.setBackground(new Color(144, 238, 144));
		three.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		three.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		three.setBounds(534, 140, 184, 77);
		frmTictactoegame.getContentPane().add(three);
		four.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(4,four);
			}
			
		});
		
		
		four.setOpaque(true);
		four.setBackground(new Color(144, 238, 144));
		four.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		four.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		four.setBounds(74, 278, 184, 77);
		frmTictactoegame.getContentPane().add(four);
		five.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(5,five);
			}
		});
		
		
		five.setOpaque(true);
		five.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		five.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		five.setBackground(new Color(144, 238, 144));
		five.setBounds(307, 278, 184, 77);
		frmTictactoegame.getContentPane().add(five);
		six.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(6,six);
			}
		});
		
		
		six.setOpaque(true);
		six.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		six.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		six.setBackground(new Color(144, 238, 144));
		six.setBounds(534, 278, 184, 77);
		frmTictactoegame.getContentPane().add(six);
		seven.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(7,seven);
			}
		});
		
		
		seven.setOpaque(true);
		seven.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		seven.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		seven.setBackground(new Color(144, 238, 144));
		seven.setBounds(74, 400, 184, 77);
		frmTictactoegame.getContentPane().add(seven);
		eight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(8,eight);
			}
		});
		
		
		eight.setOpaque(true);
		eight.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		eight.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		eight.setBackground(new Color(144, 238, 144));
		eight.setBounds(307, 400, 184, 77);
		frmTictactoegame.getContentPane().add(eight);
		nine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendZero(9,nine);
			}
		});
		
		
		nine.setOpaque(true);
		nine.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		nine.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		nine.setBackground(new Color(144, 238, 144));
		nine.setBounds(534, 400, 184, 77);
		frmTictactoegame.getContentPane().add(nine);
		frmTictactoegame.setTitle("TicTacToe-Game");
		frmTictactoegame.setBounds(100, 100, 815, 574);
		frmTictactoegame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTictactoegame.setLocationRelativeTo(null);
	}
}

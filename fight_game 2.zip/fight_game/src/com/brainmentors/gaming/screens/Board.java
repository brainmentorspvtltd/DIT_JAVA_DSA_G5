package com.brainmentors.gaming.screens;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.brainmentors.gaming.sprites.Player;
import com.brainmentors.gaming.utils.GameConstants;

public class Board extends JPanel implements GameConstants {
	BufferedImage backgroundImage;
	private Player player;
	public Board() throws Exception{
		player = new Player();
		loadBackgroundImage();
		//System.out.println("i am the board constrcutor...");
	}
	private void loadBackgroundImage() {
		try {
		backgroundImage = ImageIO.read(Board.class.getResource("game-bg.jpeg"));
		}
		catch(Exception ex) {
			JOptionPane.showMessageDialog(this,"OOPS something went wrong..");
			System.out.println(ex);
			System.exit(0);
			
		}
	}
	@Override
	public void paintComponent(Graphics pen) {
		super.paintComponent(pen);
		printBG(pen);
		player.paintPlayer(pen);
		//System.out.println("I am the Paint Component....");
	}
	
	private void printBG(Graphics pen) {
//		
		pen.drawImage(backgroundImage,0,0, GWIDTH, GHEIGHT, null);
	}

}

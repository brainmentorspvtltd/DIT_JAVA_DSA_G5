package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public class Player implements GameConstants {
	private int x;
	private int y;
	private int w;
	private int h;
	BufferedImage bi;
	public Player() throws Exception {
		x  = 100;
		y = FLOOR;
		w = 150;
		h = 150;
		bi = ImageIO.read(Player.class.getResource("sprites.png"));
	}
	
	private BufferedImage showPlayer() {
		return bi.getSubimage(162, 494, 23, 66);
	}
	
	public void paintPlayer(Graphics pen) {
		pen.drawImage(showPlayer(),x, y, w, h, null);
	}
	

}

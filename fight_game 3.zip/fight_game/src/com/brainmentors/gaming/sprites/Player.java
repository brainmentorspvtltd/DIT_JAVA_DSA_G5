package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public class Player implements GameConstants {
	private int x;
	private int y;
	private int w;
	private int h;
	private BufferedImage bi;
	private int speed;
	private BufferedImage walkImages [] = new BufferedImage[4];
	private BufferedImage kickImages [] = new BufferedImage[3];
	private int index = 0;
	private int currentMove ;
	private int force;
	public Player() throws Exception {
		x  = 180;
		h = 100;
		y = FLOOR - h;
		w = 100;
		
		bi = ImageIO.read(Player.class.getResource("sprite.gif"));
		speed = 0;
		force = 0;
		currentMove = WALK;
		loadWalk();
		loadKick();
	}
	
	
	
	public int getCurrentMove() {
		return currentMove;
	}



	public void setCurrentMove(int currentMove) {
		this.currentMove = currentMove;
		index =0;
	}



	private void loadWalk() {
		walkImages[0] = bi.getSubimage(211, 5, 24, 44);
		walkImages[1] = bi.getSubimage(235, 2, 18, 49);
		//walkImages[2] = bi.getSubimage(258, 2, 23, 48);
		//walkImages[3] = bi.getSubimage(284, 5, 20, 46);
		
	}
	
	private void loadKick() {
		kickImages[0] = bi.getSubimage(211,50, 37,45);
		kickImages[1] = bi.getSubimage(250,52,27,40);
		kickImages[2] = bi.getSubimage(276, 56,23, 37);
	}
	
	public void jump() {
		System.out.println("Call Jump...");
		force = -15;
		y = y + force;
	}
	
	public void fall() {
//		System.out.println("F "+(FLOOR-h));
//		System.out.println("Y "+y);
		if(y>=(FLOOR-h)) {
			System.out.println("Not Fall");
			return ;
		}
		System.out.println("Fall....");
		force = force + GRAVITY;
		y= y + force;
	}
	
	public void move() {
		x= x + speed;
	}
	
	
	
	public int getSpeed() {
		return speed;
	}



	public void setSpeed(int speed) {
		this.speed = speed;
	}

	private BufferedImage showPlayerKick() {
		if(index >2) {
			index =0;
			currentMove = WALK;
		}
		BufferedImage img =  kickImages[index];
		index++;
		return img;
		
	}


	private BufferedImage showWalkPlayer() {
		if(index >1) {
			index =0;
		}
//		try {
//			Thread.sleep(40);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		BufferedImage img =  walkImages[index];
		index++;
		return img;
		
	}
	
	
	
	public void paintPlayer(Graphics pen) {
		if(currentMove == WALK) {
		pen.drawImage(showWalkPlayer(),x, y, w, h, null);
		}
		else if (currentMove == KICK) {
			
			pen.drawImage(showPlayerKick(),x, y, w, h, null);
		}
	}
	

}

package com.brainmentors.gaming.screens;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.sprites.Enemy;
import com.brainmentors.gaming.sprites.Player;
import com.brainmentors.gaming.utils.EnemyTypeCord;
import com.brainmentors.gaming.utils.GameConstants;

public class Board extends JPanel implements GameConstants {
	BufferedImage backgroundImage;
	BufferedImage partOfImage;
	private Player player;
	private Enemy enemies[] ;
	//private Enemy enemy;
	private Timer timer;
	
	public Board() throws Exception{
		player = new Player();
		EnemyTypeCord.loadBatAttackEnemy(player.getSpriteImage());
		EnemyTypeCord.loadHandAttackEnemy(player.getSpriteImage());
		EnemyTypeCord.loadKnifeAttackEnemy(player.getSpriteImage());
		enemies = new Enemy[4];
		loadEnemies();
		//enemy = new Enemy(EnemyTypeCord.handAttackEnemy);
		loadBackgroundImage();
		setFocusable(true);
		bindEvents();
		gameLoop();
		//System.out.println("i am the board constrcutor...");
	}	
	
	private void loadEnemies() throws Exception {
		enemies[0] = new Enemy(EnemyTypeCord.handAttackEnemy,0);
		enemies[1] = new Enemy(EnemyTypeCord.batAttackEnemy,500);
		enemies[2] = new Enemy(EnemyTypeCord.knifeAttackEnemy,1000);
		enemies[3] = new Enemy(EnemyTypeCord.handAttackEnemy, 1500);
	}
	
	
	
	private void gameLoop() {
		timer = new Timer(DELAY, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					repaint();
					player.fall();
				
			}
		});
		timer.start();
	}
	
	private void bindEvents() {
		this.addKeyListener(new KeyAdapter() {
			
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				player.setSpeed(0);
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_LEFT) {
					player.setSpeed(-10);
					player.move();
					
				}
				else 
					if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
						player.setSpeed(10);
						player.move();
						
					}
					else if(e.getKeyCode() == KeyEvent.VK_K) {
						player.setCurrentMove(KICK);
					}
					else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
						player.jump();
					}
				
				
				
			}
		});
	}
	
	private void loadBackgroundImage() {
		try {
		backgroundImage = ImageIO.read(Board.class.getResource("game-bg.png"));
		partOfImage = backgroundImage.getSubimage(0,0,1000,200);
		}
		catch(Exception ex) {
			JOptionPane.showMessageDialog(this,"OOPS something went wrong..");
			System.out.println(ex);
			System.exit(0);
			
		}
	}
	@Override
	public void paintComponent(Graphics pen) {
		super.paintComponent(pen);
		printBG(pen);
		player.printSprite(pen);
		printEnemies(pen);
		//enemy.printSprite(pen);
		//System.out.println("I am the Paint Component....");
	}
	
	private void printEnemies(Graphics pen) {
		for(Enemy en: enemies) {
			en.printSprite(pen);
		}
	}
	
	private void printBG(Graphics pen) {
//		
		pen.drawImage(partOfImage,0,0, GWIDTH, GHEIGHT, null);
	}

}

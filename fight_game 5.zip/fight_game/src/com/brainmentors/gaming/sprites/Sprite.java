package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public abstract class Sprite implements GameConstants {
	protected int x;
	protected int y;
	protected int w;
	protected int h;
	protected BufferedImage bi;
	protected int speed;
	protected int currentMove ;
	protected int index ;
	
	public BufferedImage getSpriteImage() {
		return bi;
	}
	
	public Sprite() throws IOException {
		bi = ImageIO.read(Player.class.getResource("sprite.gif"));
h = 100;
		
		w = 100;
		y = FLOOR - h;
	}
	
	public int getCurrentMove() {
		return currentMove;
	}

	public void move() {
		x= x + speed;
	}


	public void setCurrentMove(int currentMove) {
		this.currentMove = currentMove;
		index =0;
	}
	
	public int getSpeed() {
		return speed;
	}



	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public abstract void printSprite(Graphics pen) ;
		
	
}

package com.brainmentors.gaming.utils;

public interface GameConstants {
	String TITLE  = ConfigReader.getValue("game.title");
	int GWIDTH = Integer.parseInt(ConfigReader.getValue("game.width"));
	int GHEIGHT = Integer.parseInt(ConfigReader.getValue("game.height"));;

}
